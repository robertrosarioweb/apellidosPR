<style>
  footer {
    display: none !important;
  }
</style>


```js
import * as aq from "npm:arquero";
import * as Inputs from "https://cdn.jsdelivr.net/npm/@observablehq/inputs@0.12/+esm";

const Page = document.createElement("div");
Page.id = "page"; // ✅ Add this line!

// Apply styles to ensure the body uses full viewport height and no margins
document.body.style.margin = "0";  // Remove default margin
document.body.style.height = "100vh";  // Make sure the body takes up full height of the viewport

// Use flexbox to center the Page element in the body
document.body.style.display = "flex";  // Use flexbox for the body
document.body.style.justifyContent = "center";  // Center horizontally
document.body.style.alignItems = "center";  // Center vertically
document.body.style.flexDirection = "column";  // Stack items vertically if needed
document.body.style.overflow = "auto";  // Allow scrolling on the body

// Calculate the available space for Page below the search bar (dynamic approach)
const searchBarHeight = 50;  // Approximate height of the search bar; adjust as necessary
const availableHeight = window.innerHeight - searchBarHeight;

// Styling for the page container
Page.style.position = "absolute";  // Use absolute positioning to ensure it's always centered
Page.style.top = `${searchBarHeight}px`;  // Position the container below the search bar
Page.style.left = "50%";  // Position the container at 50% from the left
Page.style.transform = "translateX(-50%)";  // Adjust position to be exactly in the center

Page.style.display = "flex";  // Use flexbox for easy item alignment
Page.style.flexDirection = "column";  // Stack items vertically
Page.style.alignItems = "flex-start";  // Align items to the start of the container
Page.style.border = "2px solid #ccc";  // Lighter border to make it more subtle
Page.style.borderRadius = "8px";  // Add rounded corners for a softer look
Page.style.padding = "20px";  // Increase padding for more breathing room inside

// Set a fixed width and height for the container
Page.style.width = "900px";  // Fixed width for the container
Page.style.height = "1050px";  // Use the calculated available height

// Gradient background using Puerto Rico Flag colors
Page.style.background = "linear-gradient(to right, #002F6C, #FFFFFF, #C8102E)";  // Blue, white, red gradient
Page.style.boxShadow = "0 4px 10px rgba(0, 0, 0, 0.1)";  // Add a subtle shadow for depth
Page.style.fontFamily = "Arial, sans-serif";  // Use a clean font for a page-like appearance
Page.style.color = "#333";  // Set a text color for better readability




// Create the content to be added to the container
const content = document.createElement("div");
content.style.border = "2px solid black";
content.style.padding = "5px";
content.style.marginLeft = "35px";
content.style.width = "calc(100% - 81px)";  
content.style.backgroundColor = "white";

const title = document.createElement("h3");
title.style.textAlign = "left";
title.style.marginTop = "20px";
title.style.color = "blue";
title.textContent = "apellidosPR";

const subtitle = document.createElement("h3");
subtitle.style.textAlign = "left";
subtitle.style.marginTop = "20px";
subtitle.style.color = "red";
subtitle.style.whiteSpace = "nowrap";
subtitle.textContent = "Una aplicación para el análisis y visualización espacial de los apellidos en Puerto Rico.";

// Append the title and subtitle to the content div
content.appendChild(title);
content.appendChild(subtitle);
Page.appendChild(content);

// Histogram creations
const histogram1container = document.createElement('div');
const histogram2container = document.createElement('div');
const histogram3container = document.createElement('div');
const histogram4container = document.createElement('div');
histogram4container.style.marginTop = "30px";

// Images
const blob = await FileAttachment("./data/logoUPR.png").blob();
const imgUPR = document.createElement("img");
imgUPR.src = URL.createObjectURL(blob);
imgUPR.alt = "UPR logo";
imgUPR.style.width = "160px";
imgUPR.style.borderRadius = "10px";

// Positioning at the top center
imgUPR.style.position = "absolute";
imgUPR.style.top = "150px";
imgUPR.style.left = "50%";
imgUPR.style.transform = "translateX(-50%)"; // Center horizontally

const blob2 = await FileAttachment("./data/logoCDAT.png").blob();
const imgCDAT = document.createElement("img");
imgCDAT.src = URL.createObjectURL(blob2);
imgCDAT.alt = "CDAT logo";
imgCDAT.style.width = "110px";
imgCDAT.style.borderRadius = "10px";

// Positioning at the top center
imgCDAT.style.position = "absolute";
imgCDAT.style.top = "150px";
imgCDAT.style.left = "70%";
imgCDAT.style.transform = "translateX(-50%)";

Page.appendChild(imgCDAT);
Page.appendChild(imgUPR);

// Input
const miApellido = document.createElement("input");
miApellido.type = "text"; 
miApellido.style.padding = "5px";  
miApellido.value = "RIVERA"; 
miApellido.readOnly = false;
miApellido.style.marginTop = "10px"; // Space between input and under text
miApellido.addEventListener("input", (e) => {
  e.target.value = e.target.value.toUpperCase(); // Force uppercase
});

miApellido.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    Update();
  }
});


// Create a container for the input and label
const inputContainer = document.createElement("div");
inputContainer.style.position = "absolute"; 
inputContainer.style.top = "150px";
inputContainer.style.left = "55px"; 
inputContainer.style.display = "flex";
inputContainer.style.flexDirection = "column";  // Stack items vertically
inputContainer.style.alignItems = "flex-start";  // Align items to the start (left)
inputContainer.style.border = "2px solid black";  // Black border with 2px width
inputContainer.style.padding = "10px";  // Add some padding inside the container
inputContainer.style.backgroundColor = "white";

// Label for input
const inputLabel = document.createElement("label");
inputLabel.textContent = "Entre apellido:  "; 
inputLabel.style.marginBottom = "5px"; 
inputLabel.style.color = "red";


// Text under the input box
const underText = document.createElement("p");
underText.textContent = "No incluya acentos ni caracteres especiales. ";  // Sample text
underText.style.fontSize = "14px";
underText.style.color = "blue";
underText.style.marginTop = "5px"; 

// Add elements to the container
inputContainer.appendChild(inputLabel);
inputContainer.appendChild(miApellido);
inputContainer.appendChild(underText);

Page.appendChild(inputContainer);

function onApellidoChange(event) {
  const nuevoApellido = event.target.value.toUpperCase();
  console.log("Apellido actualizado:", nuevoApellido);

  // Call whatever logic you want here
  Update(nuevoApellido);
}



// Now, ensure the mainContainer stays below the infoContainer
const mainContainer = document.createElement('div');
mainContainer.id = 'main-container';

// Set fixed height and width
mainContainer.style.width = '825px';  // Fixed width
mainContainer.style.height = '500px';  // Fixed height
mainContainer.style.marginTop = '350px';  // Spacing below infoContainer
mainContainer.style.border = '2px solid black';
mainContainer.style.backgroundColor = 'white';
mainContainer.style.marginLeft = '38px';
mainContainer.style.position = 'relative'; 
// Set up grid layout for mainContainer
mainContainer.style.display = 'grid';
mainContainer.style.gridTemplateColumns = 'repeat(2, 1.5fr)';
mainContainer.style.gridTemplateRows = 'repeat(2, 1.5fr)';
mainContainer.style.gap = '20px';

// Add inner vertical and horizontal cross borders, position them inside the mainContainer
const crossVertical = document.createElement('div');
crossVertical.style.position = 'absolute';
crossVertical.style.top = '0';
crossVertical.style.left = '50%';
crossVertical.style.height = '100%';
crossVertical.style.borderLeft = '2px solid black';

const crossHorizontal = document.createElement('div');
crossHorizontal.style.position = 'absolute';
crossHorizontal.style.left = '0';
crossHorizontal.style.top = '50%';
crossHorizontal.style.width = '100%';
crossHorizontal.style.borderTop = '2px solid black';

// Append cross borders inside the mainContainer
mainContainer.appendChild(crossVertical);
mainContainer.appendChild(crossHorizontal);


// Append mainContainer to the Page
Page.appendChild(mainContainer);

// Data Fetching

let geoData = null;       // Store the geo data once it's fetched
let apellidosData = null; // Store the apellidos data once it's fetched

async function fetchGeo() {
  if (!geoData) { // Check if geoData is already fetched
    geoData = await FileAttachment("./data/puertorico-geo.json").json(); // Fetch if not already done
  }
  return geoData; // Return the cached (already fetched) data
}

async function fetchApellidos() {
  if (!apellidosData) { // Check if apellidosData is already fetched
    let csvData = await FileAttachment("./data/apellidos_cleaned2.csv").csv(); // Fetch if not already done
    apellidosData = aq.from(csvData); // Store in apellidosData
  }
  return apellidosData; // Return the cached (already fetched) data
}

async function initialize() {
  await fetchGeo(); // Fetch geo data once
  await fetchApellidos(); // Fetch apellidos data once
}


async function Update(){

    // Clear old charts and info
  
  histogram1container.innerHTML = "";
  histogram2container.innerHTML = "";
  histogram3container.innerHTML = "";
  histogram4container.innerHTML = "";

 



// Now fetch the data only once and use it in the update function
  const geo = await fetchGeo(); // Use cached geoData
  const Apellidos = await fetchApellidos(); // Use cached apellidosData


function findUniqueNames(miApellidoValue, Apellidos) {
    const prefix = miApellidoValue.slice(0, 3).toLowerCase();
    const nombreInput = miApellidoValue.toLowerCase();
    let matches = new Set();

    const nombres = Apellidos._data.Nombre;

    for (let nombre of nombres) {
        const nombreLower = nombre.toLowerCase();
        if (
            nombreLower.slice(0, 3) === prefix &&
            nombreLower !== nombreInput
        ) {
            matches.add(nombre);
        }
        if (matches.size === 3) {
            break;
        }
    }

    if (matches.size >= 3) {
        return `Apellidos similares: ${Array.from(matches).slice(0, 3).join(', ')}.`;
    } else {
        return "No hay apellidos similares.";
    }
}





function contarMunicipios(datos,poblacion){
  const municipiosPR = Object.keys(poblacion)
  let conteo = {};
  municipiosPR.forEach(municipio=>{
    conteo[municipio]=0;
  });
  datos.forEach(({Municipio})=>{
    if(conteo.hasOwnProperty(Municipio.toUpperCase())){
      conteo[Municipio.toUpperCase()]++;
    }
  })
  return conteo;
}


function normalizarFrecuencia(conteo,poblacion){
  let proporcion = {};
  for (let municipio in conteo){
    if (poblacion.hasOwnProperty(municipio))
    {
      proporcion[municipio] = 100*conteo[municipio]/poblacion[municipio];
    }else{
      proporcion[municipio] = 0;
    }
  }
  return proporcion;
}

function normalizarFrecuencia_density(conteo,poblacion){
  let proporcion = {};
  for (let municipio in conteo){
    if (poblacion.hasOwnProperty(municipio))
    {
      proporcion[municipio] = 100*conteo[municipio]/poblacion[municipio];
    }else{
      proporcion[municipio] = 0;
    }
  }
  return proporcion;
}


function contarFrecuencia(arr){
  return arr.reduce((contador,palabra)=>{
    contador[palabra] = (contador[palabra]||0) +1;
    return contador;
  },{});
}






// Function to convert to the desired format
function convertToApellidosFormat(data) {
  const { Latitude, Longitude, Municipio, Nombre } = data._data;

 
  const convertedData = {
    Latitude: Latitude.map(lat => +lat), 
    Longitude: Longitude.map(lon => +lon), 
    Municipio: Municipio,
    Nombre: Nombre
  };

 
  return {
    _names: data._names,
    _data: convertedData,
    _total: data._nrows,  
    _nrows: data._nrows,
    _mask: null  
  };
}


// Now, convert the data
const apellidos = convertToApellidosFormat(Apellidos);

// You can log the formatted data to check it
console.log("Apellidos para infobox", apellidos);
  // You can now use 'geo' and 'apellidos' in your update logic
  console.log("Geo Data:", geo);
  console.log("Apellidos Data:", apellidos);

function getPopularityPosition(lastName) {
  if (!apellidos._data.Nombre) {
    console.error("Error: apellidos._data.Nombre is undefined or null.");
    return null;
  }

  // Count occurrences of each name
  const nameCount = {};
  apellidos._data.Nombre.forEach(name => {
    nameCount[name] = (nameCount[name] || 0) + 1;
  });

  const uniqueNames = Object.keys(nameCount); // Get unique names

  // Create array of names with their counts
  const nameCountsArray = uniqueNames.map(name => ({
    name: name,
    count: nameCount[name]
  }));

  // Sort by count descending
  nameCountsArray.sort((a, b) => b.count - a.count);

  // Get the rank of the searched name
  const rank = nameCountsArray.findIndex(item => item.name === lastName) + 1;

  if (rank === 0) return null; // Name not found

  return {
    rank: rank,
    popularity: nameCount[lastName],
    totalUnique: uniqueNames.length // ✅ Total number of distinct names
  };
}
const result = getPopularityPosition(miApellido.value);

function Ocurrencias(lastName) {
  if (!apellidos._data.Nombre) {
    console.error("Error: apellidos._data.Nombre is undefined or null.");
    return null;
  }

  // Count occurrences of each name
  const nameCount = {};
  apellidos._data.Nombre.forEach(name => {
    nameCount[name] = (nameCount[name] || 0) + 1; // Increment the count for the name
  });

  // Create an array of names and their counts
  const nameCountsArray = Object.keys(nameCount).map(name => ({
    name: name,
    count: nameCount[name]
  }));

  // Sort the names by count in descending order (most common first)
  nameCountsArray.sort((a, b) => b.count - a.count);

  // Find the rank of the searched name
  const rank = nameCountsArray.findIndex(item => item.name === lastName) + 1; // Add 1 to make rank 1-based

  // Return null if name is not found
  if (rank === -1) {
    return null; // Name not found
  }

  // Calculate the total number of names
  const totalNames = apellidos._data.Nombre.length;

  // Get the popularity of the name (how many times it appears out of the total)
  const popularity = nameCount[lastName];

  // Return the formatted string
  return `Hay ${popularity} personas con ese apellido de un total de ${totalNames}`;
}

// Using the function to get the position and popularity of the searched name
const cantidad = Ocurrencias(miApellido.value);
//console.log(apellidos)

const igual = findUniqueNames(miApellido.value,Apellidos)


// Create a container for the info label
const infoContainer = document.createElement("div");
infoContainer.id = "info-container"; // ✅ Add this line!
infoContainer.style.position = "absolute"; 
infoContainer.style.top = "315px";  // Adjust this value based on the previous container height
infoContainer.style.left = "55px"; 
infoContainer.style.display = "flex";  // Use flex to align items horizontally (side by side)
infoContainer.style.flexDirection = "column";  // Stack items vertically (column direction)
infoContainer.style.alignItems = "flex-start";  // Align items to the start of the container
infoContainer.style.border = "2px solid black";  // Black border with 2px width
infoContainer.style.padding = "10px";  // Add some padding inside the container
infoContainer.style.width = "86%";  // Increase the width of the container to make it longer
infoContainer.style.backgroundColor = "white";
Page.appendChild(infoContainer);



// Create a container for the info label
const alikeContainer = document.createElement("div");
alikeContainer.id = "info-container"; // ✅ Add this line!
alikeContainer.style.position = "absolute"; 
alikeContainer.style.top = "1000px";  // Adjust this value based on the previous container height
alikeContainer.style.left = "55px"; 
alikeContainer.style.display = "flex";  // Use flex to align items horizontally (side by side)
alikeContainer.style.flexDirection = "column";  // Stack items vertically (column direction)
alikeContainer.style.alignItems = "flex-start";  // Align items to the start of the container
alikeContainer.style.border = "2px solid black";  // Black border with 2px width
alikeContainer.style.padding = "10px";  // Add some padding inside the container
alikeContainer.style.width = "86%";  // Increase the width of the container to make it longer
alikeContainer.style.backgroundColor = "white";
Page.appendChild(alikeContainer);

// Create the text content for the first text (infoText)
const alikeText = document.createElement("span");  // Use a span for inline text
alikeText.textContent = igual;  // Concatenate static text with the dynamic value
alikeText.style.color = "blue";
alikeText.style.marginBottom = "10px";  // Add some space below this text (space between text elements)
alikeText.style.whiteSpace = "nowrap"; 
alikeContainer.appendChild(alikeText);

// Create the text content for the first text (infoText)
const infoText = document.createElement("span");  // Use a span for inline text
infoText.textContent = "Análisis del apellido: " + miApellido.value;  // Concatenate static text with the dynamic value
infoText.style.color = "blue";
infoText.style.marginBottom = "10px";  // Add some space below this text (space between text elements)
infoText.style.whiteSpace = "nowrap";  // Prevent the text from wrapping onto a new line

// Add the infoText to the container
infoContainer.appendChild(infoText);

// Create the text content for the rank (infoTextrank)
const infoTextrank = document.createElement("span");
infoTextrank.textContent = `Ocupa la posición #${result.rank} entre ${result.totalUnique} apellidos distintos.`;

// Add the infoTextrank to the container
infoContainer.appendChild(infoTextrank);


const infoTextcantidad = document.createElement("span");
infoTextcantidad.textContent = `${cantidad}`;

// Add the infoTextrank to the container
infoContainer.appendChild(infoTextcantidad);




const poblacion = contarFrecuencia(apellidos._data.Municipio);

const apellidosArray = apellidos._data.Nombre.map((nombre, index) => ({
  Nombre: nombre,
  Longitude: apellidos._data.Longitude[index],
  Latitude: apellidos._data.Latitude[index],
  Municipio: apellidos._data.Municipio[index]
}));


const puntosApellidos = [];
for (const d of apellidosArray) {
  if (typeof d.Nombre === "string" && d.Nombre.toUpperCase() === miApellido.value.toUpperCase())
 {
 puntosApellidos.push(d);
  }
}


console.log("Puntos Apellidos",puntosApellidos);

function frecNorm(puntosApellidos,poblacion){
    let frecuencia = contarMunicipios(puntosApellidos,poblacion);
    return normalizarFrecuencia(frecuencia,poblacion);
}

function frecNorm_dens(puntosApellidos,poblacion){
    let frecuencia = contarMunicipios(puntosApellidos,poblacion);
    return normalizarFrecuencia_density(frecuencia,poblacion);
}

const frecuenciaNormalizada = frecNorm(puntosApellidos,poblacion);
const frecuenciaNormalizada_density = frecNorm_dens(puntosApellidos,poblacion)
console.log("frecuenciaNormalizada_density",frecuenciaNormalizada_density)

let arregloObjetos = Object.entries(frecuenciaNormalizada).map(([municipio,frecuencia]) => ({
municipio,
frecuencia
}));

arregloObjetos.sort((a, b) => b.frecuencia - a.frecuencia);
let topTen = arregloObjetos.slice(0, 10);

let frec = topTen.map(d => ({
municipio: d.municipio,
frecuencia: d.frecuencia 
}));


let topfive = arregloObjetos.slice(0, 5);
let frec5 = topfive.map(d => ({
municipio: d.municipio
}));

// Create a span for the top 5 municipalities
const top5Municipios = frec5.map(d => d.municipio).join(", ");
const municipiosText = document.createElement("span");
municipiosText.textContent = `Es mas frecuente en: ${top5Municipios}`;
municipiosText.style.marginTop = "5px";  // Space from the previous line

// Append it to the container
infoContainer.appendChild(municipiosText);

let frecuenciaData = arregloObjetos.map(d => ({
municipio: d.municipio,
frecuencia: d.frecuencia 
}));

console.log("HOLAAAAAAAAAAAAAAAAAAAAAAa",frec5)

function barplot(frec){
    const plot = Plot.plot({
        height: 390,
        x: {
            axis: "bottom",  
            grid: false,      
            label: "Frecuencia Normalizada", 
            tick: {
                fontSize: 20,  // Adjust tick font size
                fontWeight: "bold",  // Make the font bold
                fontFamily: "Arial", // Optional: Change the font family for ticks
            }
        },
        y: {
            label: "Municipio"
        },
        marks: [
            Plot.ruleX([0]),  
            Plot.barX(frec, {
                x: "frecuencia",  
                y: "municipio",   
                sort: { y: "x", reverse: true },  
                fill: d => d.frecuencia,
                 stroke: "black",  // Border color
                strokeWidth: 2  
            })
        ],
        color: {
            scheme: "reds" 
        },
        marginLeft: 100,  
        marginTop: 20, 

    });

    return plot; 
}
const barPlot = barplot(frec);  



let arregloObjetos_dens = Object.entries(frecuenciaNormalizada_density).map(([municipio,frecuencia]) => ({
municipio,
frecuencia
}));

let frec_density = arregloObjetos_dens.map(d => ({
municipio: d.municipio,
frecuencia: d.frecuencia /10
}));


let frecMap = frec_density.reduce((map, { municipio, frecuencia }) => {
  map[municipio] = frecuencia;
  return map;
}, {});




const puntosConFrecuencia = puntosApellidos.map(punto => {
  return {
    ...punto,
    frecuencia: frecMap[punto.Municipio] || null 
  };
});

console.log("puntosConFrecuencia",puntosConFrecuencia);


let municipiosConFrecuencia = [];  // Global variable to hold the processed municipios data
let updatedMunicipios = [];  // Global variable for updated municipios with centroids

// The function to process the data
function processData() {
  return fetchGeo().then(puertoricoGeo => {
    // Check if puertoricoGeo.pueblos.features is an array
    if (!Array.isArray(puertoricoGeo.pueblos.features)) {
      console.error("Invalid features data in puertoricoGeo.");
      return [];  // Return an empty array if data is invalid
    }

    // Convert frecuenciaData into a map for fast lookup (standardize municipio names to lowercase)
    const frecuenciaMap = new Map(frecuenciaData.map(item => [item.municipio.trim().toLowerCase(), item.frecuencia]));

    // Now add the frecuencias to municipiosConFrecuencia based on the municipio name
    municipiosConFrecuencia = puertoricoGeo.pueblos.features.map(feature => {
      const municipioNombre = feature.properties.NAME?.trim().toLowerCase(); // Standardize municipio names

      if (!municipioNombre) {
        console.warn(`Missing or invalid NAME in feature:`, feature);
        return feature;  // Skip invalid features by returning the original feature
      }

      // Get the frecuencia value from the map, default to null if not found
      const frecuencia = frecuenciaMap.get(municipioNombre) || null;

      // Return the updated feature with the assigned frecuencia
      return {
        type: feature.type,
        properties: {
          ...feature.properties,
          frecuencia: frecuencia + 1.0e-6, // Add the frecuencia to the properties
        },
        geometry: feature.geometry
      };
    });

   

    // Update the municipalities with centroids
    updatedMunicipios = municipiosConFrecuencia.map(municipio => {
      const coordinates = municipio.geometry.coordinates[0];  // Assuming only one polygon
      const centroid = computeCentroid(coordinates);  // Calculate the centroid

      return {
        ...municipio,
        properties: {
          ...municipio.properties,
          centroid: centroid
        }
      };
    });

    return { municipiosConFrecuencia, updatedMunicipios };  // Return both variables
  }).catch(error => {
    console.error("Error while processing data:", error);
    return [];  // Return an empty array in case of error
  });
}

// Compute the centroid of a polygon (helper function)
function computeCentroid(coords) {
  let xSum = 0, ySum = 0, n = coords.length;
  coords.forEach(([x, y]) => {
    xSum += x;
    ySum += y;
  });
  return [xSum / n, ySum / n]; // Return the average coordinates
}


// Assuming processData() has already been run and data is available in updatedMunicipios
processData().then(({ municipiosConFrecuencia, updatedMunicipios }) => {
  // Create the plot inside histogram2container
  console.log("MunicipiosConFrecuencia",municipiosConFrecuencia);
  console.log("FrecuenciaData",frecuenciaData);
  const plot = Plot.plot({
    width:1200,
    marginBottom: 100,
    marginTop: 110,
    marginLeft: 20,
    marginRight: 20,
    r: { range: [7, 25] },  // Size range for the circles
    x: { axis: null },  // Hide the x-axis
    y: { axis: null },  // Hide the y-axis
    style: {
      background: "white"  // Set dark background for the plot
    },
    marks: [
      // Plot the boundaries of each municipality (using Plot.geo)
      Plot.geo(municipiosConFrecuencia, {
        stroke: "#000000",  // Black boundary stroke
        strokeOpacity: 1,   
        strokeWidth: 1,     
        tip: true,          
        title: "properties.NAME",  // Hover title showing municipality name
        fill: "#1e1e1e"  // Dark fill for the polygons
      }),

      // Plot circles at the centroids with radius based on frequency
      Plot.circle(updatedMunicipios, {
        x: ({ properties }) => properties.centroid[0],  // Longitude (x) of the centroid
        y: ({ properties }) => properties.centroid[1],  // Latitude (y) of the centroid
        r: "frecuencia",  // Circle radius based on the 'frecuencia' property
        fill: ({ properties }) => {
          // Use a color scale to color the circles based on frequency
          const colorScale = d3.scaleSequential(d3.interpolateReds)
            .domain([0, d3.max(updatedMunicipios, d => d.properties.frecuencia)]); 
        
          return colorScale(properties.frecuencia);  // Return color based on frequency
        },
        fillOpacity: 0.9,  // Opacity of the circles
        stroke: "#1e1e1e",  // Dark border for the circles
        strokeOpacity: 0.5,  // Border opacity
        tip: true,  // Show a tooltip on hover
        title: "properties.NAME"  // Hover title showing municipality name
      })
    ]
  });
    const plotChoro =Plot.plot({
    height:610,
    width: 1220,
    marginBottom: 100,
    marginTop: 100,
    marginLeft: 20,
    marginRight: 20,
    x: { axis: null },
    y: { axis: null },
    style: {
        background: "white"
    },
    marks: [
        Plot.geo(municipiosConFrecuencia, {
        stroke: "#000000",
        strokeOpacity: 2,
        strokeWidth: 2,
        tip: true,
        title: "name",
        fill: (d) => d.properties.frecuencia 
        }),
        
    ],color: {
        scheme: "reds" 
        },
    })

    const densityPlot = Plot.plot({
   x: { axis: null },
  y: { axis: null },
  marks: [
    Plot.geo(municipiosConFrecuencia, {
      stroke: "#000000",  
      strokeOpacity: 1,   
      strokeWidth: 1,     
      tip: true,          
      title: "properties.NAME",
      fill: "#1e1e1e" 
    }),
    Plot.dot(puntosConFrecuencia, {x: "Longitude", y: "Latitude", fill: "white", opacity: 0.7, r: 1}),
    Plot.density(puntosConFrecuencia, {x: "Longitude", y: "Latitude", fill: "density", opacity: 0.6, bandwidth: 10, weight:"frecuencia"}),
    
  ],
  width: 1190,
  height: 410
});

  // Append the plot to the histogram2container
  histogram2container.appendChild(plot);
  
  histogram3container.appendChild(plotChoro);
  
  
  histogram4container.appendChild(densityPlot);
  
histogram1container.appendChild(barPlot);


}).catch(error => {
  console.error("Error while processing data:", error);
});

mainContainer.appendChild(histogram1container);
mainContainer.appendChild(histogram2container);
mainContainer.appendChild(histogram3container);
mainContainer.appendChild(histogram4container);

document.body.appendChild(Page);
// Adjust the body to allow scrolling when zoomed
document.body.style.minHeight = "100vh";  // Make sure the body is at least the height of the viewport
document.body.style.margin = "0";  // Remove default margin
}
initialize();
Update();

